from django.contrib import admin
from datamodel.models import Game, Move
admin.site.register(Game)
admin.site.register(Move)

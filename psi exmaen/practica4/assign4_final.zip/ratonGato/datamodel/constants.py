GAME_SELECTED_SESSION_ID = 'game_selected'
ERROR_MESSAGE_ID = 'msg_error'

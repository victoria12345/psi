from django.contrib import admin
from aplicacion.models import Pelicula, Productora, Produce

# Register your models here.

admin.site.register(Pelicula)
admin.site.register(Productora)
admin.site.register(Produce)

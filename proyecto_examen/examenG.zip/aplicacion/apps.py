from django.apps import AppConfig


class AplicacionConfig(AppConfig):
    name = 'aplicacion'
